import respx
import pytest
from httpx import HTTPStatusError, Request, Response, TimeoutException

from mcp_meroshare.client import (
    MeroShareClient,
    format_error,
)

_TEST_CFG = {
    "MERO_SHARE_CLIENT_ID": "1",
    "MERO_SHARE_USERNAME": "u",
    "MERO_SHARE_PASSWORD": "p",
    "MERO_SHARE_CRN_NUMBER": "c",
    "MERO_SHARE_TRANSACTION_PIN": "t",
}


async def login(client: MeroShareClient, api_mock, monkeypatch):
    api_mock.post("/auth/").respond(
        200,
        headers={"Authorization": "Bearer test-token"},
        json={"name": "Test User"},
    )
    monkeypatch.setattr("mcp_meroshare.client._read_profile_config", lambda p: dict(_TEST_CFG))
    monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
    await client.login(profile="test")


# ---------------------------------------------------------------------------
# format_error
# ---------------------------------------------------------------------------

class TestFormatError:
    def test_httpx_status_error(self):
        request = Request("GET", "http://test.com")
        resp = Response(500, text="Internal Server Error", request=request)
        err = HTTPStatusError("Server Error", request=request, response=resp)
        msg = format_error(err)
        assert "HTTP 500" in msg

    def test_timeout_error(self):
        msg = format_error(TimeoutException("Connection timed out"))
        assert "timed out" in msg

    def test_runtime_error(self):
        msg = format_error(RuntimeError("Not logged in"))
        assert msg == "Not logged in"

    def test_generic_error(self):
        msg = format_error(ValueError("bad value"))
        assert "ValueError" in msg


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestLogin:
    async def test_login_success(self, client, api_mock, view_mock, monkeypatch):
        api_mock.post("/auth/").respond(
            200,
            headers={"Authorization": "Bearer test-token"},
            json={"name": "Test User", "username": "user"},
        )
        monkeypatch.setattr("mcp_meroshare.client._read_profile_config", lambda p: dict(_TEST_CFG))
        monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
        result = await client.login(profile="test")
        assert result["name"] == "Test User"
        assert client.logged_in
        assert client.crn_number == "c"
        assert client.transaction_pin == "t"

    async def test_login_missing_client_id(self, client):
        with pytest.raises(RuntimeError, match="client_id is required"):
            await client.login(profile="nonexistent")

    async def test_login_resolves_from_dp_code(self, client, api_mock, monkeypatch):
        api_mock.get("/capital/").respond(
            200,
            json=[{"id": 42, "code": "10600", "name": "Test DP"}],
        )
        api_mock.post("/auth/").respond(
            200,
            headers={"Authorization": "Bearer t"},
            json={"name": "U"},
        )
        monkeypatch.setattr("mcp_meroshare.client._read_profile_config", lambda p: {
            "MERO_SHARE_DP_CODE": "10600",
            "MERO_SHARE_USERNAME": "u",
            "MERO_SHARE_PASSWORD": "p",
            "MERO_SHARE_CRN_NUMBER": "c",
            "MERO_SHARE_TRANSACTION_PIN": "t",
        })
        monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
        monkeypatch.setattr("mcp_meroshare.client._load_capital_cache", lambda: None)
        monkeypatch.setattr("mcp_meroshare.client._save_capital_cache", lambda *a, **kw: None)
        result = await client.login(profile="test")
        assert result["name"] == "U"
        assert client.logged_in

    async def test_login_reauth_logs_out_first(self, client, api_mock, view_mock, monkeypatch):
        api_mock.post("/auth/").respond(
            200,
            headers={"Authorization": "Bearer token"},
            json={"name": "User"},
        )
        api_mock.post("/auth/logout/").respond(200, json={})
        cfg_a = dict(_TEST_CFG, MERO_SHARE_USERNAME="u1", MERO_SHARE_CRN_NUMBER="crn1")
        cfg_b = dict(_TEST_CFG, MERO_SHARE_USERNAME="u2", MERO_SHARE_CRN_NUMBER="crn2")
        monkeypatch.setattr("mcp_meroshare.client._read_profile_config", lambda p: cfg_a if p == "a" else cfg_b)
        monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)

        await client.login(profile="a")
        assert client.logged_in
        assert client.crn_number == "crn1"

        await client.login(profile="b")
        assert client.logged_in
        assert client.crn_number == "crn2"


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestEnsureSession:
    async def test_raises_if_not_logged_in(self, client):
        with pytest.raises(RuntimeError, match="Not logged in"):
            await client._ensure_session()

    async def test_passes_after_login(self, client, api_mock, view_mock, monkeypatch):
        api_mock.post("/auth/").respond(
            200, headers={"Authorization": "Bearer t"}, json={},
        )
        monkeypatch.setattr("mcp_meroshare.client._read_profile_config", lambda p: dict(_TEST_CFG))
        monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
        await client.login(profile="test")
        assert await client._ensure_session() is None


# ---------------------------------------------------------------------------
# DP list
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestGetDpList:
    async def test_returns_list(self, client, api_mock):
        api_mock.get("/capital/").respond(
            200,
            json=[{"id": 1, "code": "10400", "name": "NABIL INVESTMENT BANKING LTD."}],
        )
        dps = await client.get_dp_list(use_cache=False)
        assert len(dps) == 1
        assert dps[0]["code"] == "10400"

    async def test_handles_dict_response(self, client, api_mock):
        api_mock.get("/capital/").respond(
            200,
            json={"object": [{"id": 1, "code": "10400", "name": "TEST"}]},
        )
        dps = await client.get_dp_list(use_cache=False)
        assert len(dps) == 1

    async def test_raises_on_unexpected_format(self, client, api_mock):
        api_mock.get("/capital/").respond(200, json="invalid")
        with pytest.raises(RuntimeError, match="Unexpected response format"):
            await client.get_dp_list(use_cache=False)

    async def test_uses_cache(self, client, api_mock, monkeypatch):
        api_mock.get("/capital/").respond(200, json=[])
        monkeypatch.setattr("mcp_meroshare.client._load_capital_cache", lambda: [{"id": 99}])
        dps = await client.get_dp_list(use_cache=True)
        assert dps == [{"id": 99}]


# ---------------------------------------------------------------------------
# Issues — open (VIEW_OPEN_SHARE)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestCurrentOpenIssues:
    async def test_fetch_open_issues(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.post("/companyShare/currentIssue").respond(
            200,
            json={"object": [{"companyShareId": 1, "companyName": "Test IPO"}]},
        )
        issues = await client.get_current_open_issues()
        assert len(issues) == 1
        assert issues[0]["companyName"] == "Test IPO"

    async def test_fetch_all_paginates(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        call_count = 0
        many = [{"companyShareId": i} for i in range(200)]

        def handler(request):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return Response(200, json={"object": many})
            return Response(200, json={"object": []})

        api_mock.post("/companyShare/currentIssue").side_effect = handler
        issues = await client.get_current_open_issues(fetch_all=True)
        assert len(issues) == 200
        assert call_count == 2

    async def test_raises_if_not_logged_in(self, client):
        with pytest.raises(RuntimeError, match="Not logged in"):
            await client.get_current_open_issues()


# ---------------------------------------------------------------------------
# Issues — applicable (VIEW_APPLICABLE_SHARE)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestApplicableIssues:
    async def test_fetch_applicable(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.post("/companyShare/applicableIssue/").respond(
            200,
            json={"object": [{"companyShareId": 2}]},
        )
        issues = await client.get_applicable_issues()
        assert len(issues) == 1
        assert issues[0]["companyShareId"] == 2


# ---------------------------------------------------------------------------
# Issue details
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestIssueDetails:
    async def test_fetch_details(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.get("/active/42").respond(
            200,
            json={"companyName": "Test Corp", "minUnit": 10, "maxUnit": 100},
        )
        detail = await client.get_issue_details(42)
        assert detail["companyName"] == "Test Corp"
        assert detail["minUnit"] == 10


# ---------------------------------------------------------------------------
# Right share
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestRightShare:
    async def test_get_share_criteria(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        with respx.mock(base_url="https://backend.cdsc.com.np/api/shareCriteria") as sm:
            sm.get("/boid/DEMAT/42").respond(
                200, json={"reservedQuantity": 50, "shareCriteriaId": 1},
            )
            monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
            result = await client.get_share_criteria("DEMAT", 42)
        assert result["reservedQuantity"] == 50

    async def test_validate_boid(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        with respx.mock(base_url="https://backend.cdsc.com.np/api/shareCriteria") as sm:
            sm.post("/validate/42").respond(200, json={"eligible": True})
            monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
            result = await client.validate_boid_for_right_share(42, "DEMAT")
        assert result["eligible"] is True


# ---------------------------------------------------------------------------
# Application report
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestApplicationReport:
    async def test_fetch_report(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.post("/applicantForm/active/search/").respond(
            200,
            json={"object": [{"companyShareId": 1, "companyName": "Test", "appliedKitta": 10}]},
        )
        reports = await client.get_application_report()
        assert len(reports) == 1
        assert reports[0]["appliedKitta"] == 10


# ---------------------------------------------------------------------------
# Apply IPO
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestApplyIpo:
    async def test_can_apply_returns_true(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.get("/applicantForm/customerType/1/123").respond(
            200, json={"message": "You can apply for this issue."},
        )
        assert await client.can_apply_to_ipo(1, "123") is True

    async def test_can_apply_returns_false_on_409(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.get("/applicantForm/customerType/1/123").respond(409)
        assert await client.can_apply_to_ipo(1, "123") is False

    async def test_apply_success(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        api_mock.post("/applicantForm/share/apply").respond(
            200, json={"message": "Applied successfully"},
        )
        monkeypatch.setattr("mcp_meroshare.client._pace", lambda *a, **kw: None)
        result = await client.apply_for_ipo({"companyShareId": "1"})
        assert result["message"] == "Applied successfully"


# ---------------------------------------------------------------------------
# Transactions
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestTransactions:
    async def test_get_transactions(self, client, api_mock, view_mock, monkeypatch):
        await login(client, api_mock, monkeypatch)
        view_mock.get("/myTransaction/BOID123").respond(
            200, json=[{"transactionNo": "T1", "scrip": "SCP"}],
        )
        txns = await client.get_transactions("BOID123")
        assert len(txns) == 1
        assert txns[0]["transactionNo"] == "T1"


# ---------------------------------------------------------------------------
# Retry
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
class TestRetry:
    async def test_retries_on_5xx(self, client, api_mock):
        call_count = 0

        def handler(request):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return Response(502, text="Bad Gateway")
            return Response(200, json=[{"id": 1, "code": "10400", "name": "TEST"}])

        api_mock.get("/capital/").side_effect = handler
        result = await client.get_dp_list(use_cache=False)
        assert call_count == 3
        assert len(result) == 1
        assert result[0]["code"] == "10400"
