import asyncio
import json
import logging
import os
import pathlib
import random
import time
import httpx
import keyring
from typing import Any


logger = logging.getLogger(__name__)

BASE_URL = "https://backend.cdsc.com.np/api/meroShare"
VIEW_URL = "https://backend.cdsc.com.np/api/meroShareView"
SHARE_CRITERIA_URL = "https://backend.cdsc.com.np/api/shareCriteria"

BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.9",
    "Origin": "https://meroshare.cdsc.com.np",
    "Referer": "https://meroshare.cdsc.com.np/",
    "Content-Type": "application/json",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "Pragma": "no-cache",
    "Cache-Control": "no-cache",
}

SESSION_TIMEOUT = int(os.getenv("MERO_SHARE_SESSION_TIMEOUT", str(15 * 60)))
MAX_RETRIES = int(os.getenv("MERO_SHARE_MAX_RETRIES", "2"))
KEYRING_SERVICE = "mcp-meroshare"
CAPITAL_CACHE_TTL = int(os.getenv("MERO_SHARE_CAPITAL_CACHE_TTL", str(24 * 3600)))
MAX_PAGES = 10
PAGE_SIZE = 200


_PROFILES_KEY = "__profiles__"


def _keyring_set(profile: str, config: dict[str, str]) -> None:
    keyring.set_password(KEYRING_SERVICE, profile, json.dumps(config))


def _keyring_get(profile: str) -> dict[str, str] | None:
    try:
        raw = keyring.get_password(KEYRING_SERVICE, profile)
        if raw:
            data = json.loads(raw)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return None


def _keyring_delete(profile: str) -> None:
    try:
        keyring.delete_password(KEYRING_SERVICE, profile)
    except Exception:
        pass


def _profiles_index() -> dict[str, Any]:
    index = _keyring_get(_PROFILES_KEY)
    return index if isinstance(index, dict) else {}


def _save_profiles_index(index: dict[str, Any]) -> None:
    _keyring_set(_PROFILES_KEY, index)


def format_error(e: Any) -> str:
    if isinstance(e, httpx.HTTPStatusError):
        body = e.response.text[:500]
        return f"HTTP {e.response.status_code}: {body}"
    if isinstance(e, httpx.TimeoutException):
        return "Request timed out. The server may be slow; please try again."
    if isinstance(e, httpx.RequestError):
        return f"Network error: {e}"
    if isinstance(e, RuntimeError):
        return str(e)
    return f"{type(e).__name__}: {e}"


def _read_profile_config(profile: str) -> dict[str, str]:
    config = _keyring_get(profile)
    return config if config is not None else {}


def _resolve_config(key: str, config: dict[str, str]) -> str | None:
    return config.get(key) or os.getenv(key)


def _run_sync(client: httpx.Client, method: str, url: str, **kwargs: Any) -> httpx.Response:
    return client.request(method, url, **kwargs)


def _pace(min_s: float = 1, max_s: float = 4) -> None:
    time.sleep(random.uniform(min_s, max_s))


def _capital_cache_dir() -> pathlib.Path:
    p = pathlib.Path.home() / ".cache" / "mcp-meroshare"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _capital_cache_path() -> pathlib.Path:
    return _capital_cache_dir() / "capital_cache.json"


def _load_capital_cache() -> list[dict[str, Any]] | None:
    path = _capital_cache_path()
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text())
        if isinstance(raw, dict) and isinstance(raw.get("data"), list):
            fetched_at = raw.get("fetched_at", 0)
            if time.time() - fetched_at < CAPITAL_CACHE_TTL:
                return raw["data"]
    except (OSError, ValueError, TypeError):
        pass
    return None


def _save_capital_cache(data: list[dict[str, Any]]) -> None:
    path = _capital_cache_path()
    tmp = path.with_suffix(".json.tmp")
    try:
        tmp.write_text(json.dumps({"data": data, "fetched_at": time.time()}))
        tmp.chmod(0o600)
        tmp.rename(path)
    except OSError as e:
        logger.debug("Could not persist capital cache: %s", e)


class MeroShareClient:
    def __init__(self) -> None:
        self._client = httpx.Client(
            base_url=BASE_URL,
            timeout=30.0,
            headers=dict(BROWSER_HEADERS),
        )
        self._view_client: httpx.Client = httpx.Client(
            base_url=VIEW_URL,
            timeout=30.0,
            headers=dict(BROWSER_HEADERS),
        )
        self._lock = asyncio.Lock()
        self._logged_in = False
        self._last_activity: float | None = None
        self._profile: str | None = None
        self._password: str | None = None
        self._crn_number: str | None = None
        self._transaction_pin: str | None = None

    @staticmethod
    def save_credentials(
        client_id: int,
        username: str,
        password: str,
        crn_number: str,
        profile: str = "default",
        transaction_pin: str | None = None,
        dp_name: str = "",
        dp_code: str | None = None,
    ) -> str:
        config = {
            "MERO_SHARE_CLIENT_ID": str(client_id),
            "MERO_SHARE_USERNAME": username,
            "MERO_SHARE_PASSWORD": password,
            "MERO_SHARE_CRN_NUMBER": crn_number,
        }
        if dp_code:
            config["MERO_SHARE_DP_CODE"] = str(dp_code)
        if transaction_pin:
            config["MERO_SHARE_TRANSACTION_PIN"] = transaction_pin

        _keyring_set(profile, config)
        index = _profiles_index()
        index[profile] = {"dp_name": dp_name}
        _save_profiles_index(index)
        return f"keychain (profile: {profile})"

    @staticmethod
    def delete_credentials(profile: str) -> bool:
        _keyring_delete(profile)
        index = _profiles_index()
        if profile in index:
            del index[profile]
            _save_profiles_index(index)
            return True
        return False

    @staticmethod
    def list_configured_profiles() -> dict[str, Any]:
        return _profiles_index()

    async def _request(self, client: httpx.Client, method: str, url: str, **kwargs: Any) -> httpx.Response:
        last_exc: Exception | None = None
        for attempt in range(1, MAX_RETRIES + 2):
            try:
                resp = await asyncio.to_thread(_run_sync, client, method, url, **kwargs)
                resp.raise_for_status()
                return resp
            except httpx.HTTPStatusError as e:
                if e.response.status_code < 500 or attempt > MAX_RETRIES:
                    raise
                logger.warning(
                    "HTTP %d on %s %s, retrying (%d/%d)",
                    e.response.status_code, method.upper(), url, attempt, MAX_RETRIES,
                )
                await asyncio.sleep(0.5 * attempt)
                last_exc = e
            except (httpx.TimeoutException, httpx.NetworkError) as e:
                if attempt > MAX_RETRIES:
                    raise
                logger.warning(
                    "Network error on %s %s, retrying (%d/%d)",
                    method.upper(), url, attempt, MAX_RETRIES,
                )
                await asyncio.sleep(1.0 * attempt)
                last_exc = e
        raise last_exc or RuntimeError(f"Request failed after {MAX_RETRIES + 1} attempts")

    async def _ensure_session(self) -> None:
        async with self._lock:
            if not self._logged_in:
                raise RuntimeError("Not logged in. Call meroshare_login first.")
            now = time.monotonic()
            if self._last_activity is not None and (now - self._last_activity) > SESSION_TIMEOUT:
                logger.warning("Session expired after %d seconds of inactivity", SESSION_TIMEOUT)
                self._logged_in = False
                self._client.headers.pop("Authorization", None)
                self._view_client.headers.pop("Authorization", None)
                self._view_client.cookies.clear()
                self._client.cookies.clear()
                raise RuntimeError(
                    f"Session expired after {SESSION_TIMEOUT} seconds of inactivity. "
                    "Call meroshare_login again."
                )
            self._last_activity = now

    @property
    def logged_in(self) -> bool:
        return self._logged_in

    @property
    def crn_number(self) -> str:
        if self._crn_number is None:
            raise RuntimeError("CRN number not loaded. Login first.")
        return self._crn_number

    @property
    def transaction_pin(self) -> str | None:
        return self._transaction_pin

    async def _logout_unlocked(self) -> None:
        if not self._logged_in:
            return
        try:
            await asyncio.to_thread(self._client.post, "/auth/logout/")
        except Exception:
            pass
        self._logged_in = False
        self._profile = None
        self._last_activity = None
        self._password = None
        self._crn_number = None
        self._transaction_pin = None
        self._client.headers.pop("Authorization", None)
        self._view_client.headers.pop("Authorization", None)
        self._view_client.cookies.clear()
        self._client.cookies.clear()

    async def _resolve_client_id(self, config: dict[str, str]) -> str:
        client_id = _resolve_config("MERO_SHARE_CLIENT_ID", config)
        if client_id is not None:
            return client_id
        dp_code = _resolve_config("MERO_SHARE_DP_CODE", config)
        if dp_code is not None:
            dps = await self.get_dp_list()
            for dp in dps:
                if str(dp.get("code", "")) == str(dp_code) or str(dp.get("id", "")) == str(dp_code):
                    return str(dp["id"])
            raise RuntimeError(
                f"DP code '{dp_code}' not found in capital list. "
                "Run `mcp-meroshare get-dp-list` for valid codes."
            )
        raise RuntimeError(
            "client_id is required. Set MERO_SHARE_CLIENT_ID or MERO_SHARE_DP_CODE "
            "via env var or run `mcp-meroshare add`"
        )

    async def login(
        self,
        profile: str = "default",
    ) -> dict[str, Any]:
        async with self._lock:
            if self._logged_in:
                await self._logout_unlocked()

            self._profile = profile
            config = _read_profile_config(profile)

            resolved_client_id = await self._resolve_client_id(config)

            resolved_username = _resolve_config("MERO_SHARE_USERNAME", config)
            if resolved_username is None:
                raise RuntimeError(
                    "username is required. Set MERO_SHARE_USERNAME via env var "
                    f"or run `mcp-meroshare add --profile {profile}`"
                )

            self._password = _resolve_config("MERO_SHARE_PASSWORD", config)
            self._crn_number = _resolve_config("MERO_SHARE_CRN_NUMBER", config)
            self._transaction_pin = _resolve_config("MERO_SHARE_TRANSACTION_PIN", config)

            if not self._password:
                raise RuntimeError(
                    f"MERO_SHARE_PASSWORD not configured for profile '{profile}'. "
                    "Run `mcp-meroshare add` or set the MERO_SHARE_PASSWORD env var."
                )
            if not self._crn_number:
                raise RuntimeError(
                    f"MERO_SHARE_CRN_NUMBER not configured for profile '{profile}'. "
                    "Run `mcp-meroshare add` or set the MERO_SHARE_CRN_NUMBER env var."
                )

            _pace(1, 3)
            body = {
                "clientId": int(resolved_client_id),
                "username": resolved_username,
                "password": self._password,
            }
            resp = await self._request(self._client, "POST", "/auth/", json=body)
            if resp.status_code != 200:
                if resp.status_code in (429, 403):
                    raise RuntimeError(
                        "Login throttled by MeroShare (HTTP {})".format(resp.status_code) +
                        ". Wait a few minutes before retrying."
                    )
                if resp.status_code in (401, 400):
                    raise RuntimeError(
                        "Login failed: HTTP {}. Credentials may be wrong.".format(resp.status_code)
                    )
            token = resp.headers.get("Authorization")
            if token:
                self._client.headers["Authorization"] = token
                self._view_client.headers["Authorization"] = token
            self._view_client.cookies.update(self._client.cookies)
            self._logged_in = True
            self._last_activity = time.monotonic()
            logger.info("Logged in as %s (profile: %s)", resolved_username, profile)
            return resp.json()

    async def logout(self) -> None:
        async with self._lock:
            await self._logout_unlocked()
            logger.info("Logged out")

    # ── Issues ──────────────────────────────────────────────────────

    async def _fetch_all_pages(
        self, url: str, body_template: dict,
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for page in range(1, MAX_PAGES + 1):
            body = dict(body_template, page=page, size=PAGE_SIZE)
            resp = await self._request(self._client, "POST", url, json=body)
            data = resp.json() or {}
            chunk = data.get("object", []) or []
            results.extend(chunk)
            if len(chunk) < PAGE_SIZE:
                break
            total = data.get("totalNoOfRows")
            if isinstance(total, int) and len(results) >= total:
                break
            _pace(1, 2)
        return results

    async def get_applicable_issues(
        self, fetch_all: bool = False, page: int = 1, size: int = 10,
    ) -> list[dict[str, Any]]:
        """Issues the logged-in user is eligible to apply for (VIEW_APPLICABLE_SHARE)."""
        await self._ensure_session()
        body = {
            "filterFieldParams": [
                {"key": "companyShare.companyIssue.companyISIN.script", "alias": "Scrip"},
                {"key": "companyShare.companyIssue.companyISIN.company.name", "alias": "Company Name"},
                {"key": "companyShare.companyIssue.assignedToClient.name", "value": "", "alias": "Issue Manager"},
            ],
            "searchRoleViewConstants": "VIEW_APPLICABLE_SHARE",
            "filterDateParams": [
                {"key": "minIssueOpenDate", "condition": "", "alias": "", "value": ""},
                {"key": "maxIssueOpenDate", "condition": "", "alias": "", "value": ""},
            ],
        }
        if fetch_all:
            return await self._fetch_all_pages("/companyShare/applicableIssue/", body)
        body["page"] = page
        body["size"] = size
        resp = await self._request(
            self._client, "POST", "/companyShare/applicableIssue/", json=body,
        )
        return (resp.json() or {}).get("object", [])

    async def get_current_open_issues(
        self, fetch_all: bool = False, page: int = 1, size: int = 10,
    ) -> list[dict[str, Any]]:
        """All currently open issues (VIEW_OPEN_SHARE) — no eligibility filter."""
        await self._ensure_session()
        body = {
            "filterFieldParams": [
                {"key": "companyIssue.companyISIN.script", "alias": "Scrip"},
                {"key": "companyIssue.companyISIN.company.name", "alias": "Company Name"},
                {"key": "companyIssue.assignedToClient.name", "value": "", "alias": "Issue Manager"},
            ],
            "searchRoleViewConstants": "VIEW_OPEN_SHARE",
            "filterDateParams": [
                {"key": "minIssueOpenDate", "condition": "", "alias": "", "value": ""},
                {"key": "maxIssueOpenDate", "condition": "", "alias": "", "value": ""},
            ],
        }
        if fetch_all:
            return await self._fetch_all_pages("/companyShare/currentIssue", body)
        body["page"] = page
        body["size"] = size
        resp = await self._request(
            self._client, "POST", "/companyShare/currentIssue", json=body,
        )
        return (resp.json() or {}).get("object", [])

    async def get_issue_details(self, company_share_id: int) -> dict[str, Any]:
        """Detailed info about a specific issue: min/max kitta, price, dates."""
        await self._ensure_session()
        resp = await self._request(
            self._client, "GET", f"/active/{company_share_id}",
        )
        return resp.json()

    # ── Account Info ────────────────────────────────────────────────

    async def get_own_detail(self) -> dict[str, Any]:
        await self._ensure_session()
        resp = await self._request(self._client, "GET", "/ownDetail/")
        return resp.json()

    async def get_banks(self) -> list[dict[str, Any]]:
        await self._ensure_session()
        resp = await self._request(self._client, "GET", "/bank/")
        return resp.json()

    async def get_bank_accounts(self, bank_id: int) -> list[dict[str, Any]]:
        await self._ensure_session()
        resp = await self._request(self._client, "GET", f"/bank/{bank_id}")
        return resp.json()

    async def get_bank_details(self, demat: str) -> list[dict[str, Any]]:
        banks = await self.get_banks()
        result = []
        for bank in banks:
            accounts = await self.get_bank_accounts(bank["id"])
            for acct in accounts:
                acct["bankId"] = bank["id"]
                acct["bankCode"] = bank.get("code", "")
                acct["bankName"] = bank.get("name", "")
                result.append(acct)
        return result

    async def get_dp_list(self, use_cache: bool = True) -> list[dict[str, Any]]:
        if use_cache:
            cached = _load_capital_cache()
            if cached is not None:
                return cached
        resp = await self._request(self._client, "GET", "/capital/")
        data = resp.json()
        if isinstance(data, dict):
            data = data.get("object", [])
        elif not isinstance(data, list):
            raise RuntimeError(f"Unexpected response format from /capital/: {type(data).__name__}")
        _save_capital_cache(data)
        return data

    # ── Right Share ─────────────────────────────────────────────────

    async def get_share_criteria(self, demat: str, company_share_id: int) -> dict[str, Any]:
        """Right share eligibility: reserved quantity for a BOID."""
        await self._ensure_session()
        _pace(1, 3)
        resp = await self._request(
            self._client, "GET",
            f"{SHARE_CRITERIA_URL}/boid/{demat}/{company_share_id}",
        )
        return resp.json()

    async def validate_boid_for_right_share(
        self, company_share_id: int, demat: str,
    ) -> dict[str, Any]:
        """Validate BOID eligibility for a right share issue."""
        await self._ensure_session()
        _pace(1, 2)
        resp = await self._request(
            self._client, "POST",
            f"{SHARE_CRITERIA_URL}/validate/{company_share_id}",
            json={"boid": demat},
        )
        return resp.json() if resp.text.strip() else {}

    # ── IPO Application ─────────────────────────────────────────────

    async def can_apply_to_ipo(self, company_share_id: int, demat: str) -> bool:
        await self._ensure_session()
        for attempt in range(1, MAX_RETRIES + 2):
            resp = await asyncio.to_thread(
                self._client.get, f"/applicantForm/customerType/{company_share_id}/{demat}"
            )
            if resp.status_code in (200, 202):
                try:
                    msg = resp.json().get("message", "")
                except json.JSONDecodeError:
                    msg = ""
                return "can apply" in msg.lower()
            if resp.status_code == 409:
                return False
            if resp.status_code >= 500 and attempt <= MAX_RETRIES:
                logger.warning(
                    "HTTP %d on GET /applicantForm/customerType/..., retrying (%d/%d)",
                    resp.status_code, attempt, MAX_RETRIES,
                )
                await asyncio.sleep(0.5 * attempt)
                continue
            return False
        return False

    async def apply_for_ipo(self, payload: dict[str, Any]) -> dict[str, Any]:
        await self._ensure_session()
        _pace(1, 3)
        resp = await self._request(
            self._client, "POST", "/applicantForm/share/apply", json=payload,
        )
        return resp.json()

    # ── Application Report ──────────────────────────────────────────

    async def get_application_report(
        self, fetch_all: bool = False, page: int = 1, size: int = 10,
    ) -> list[dict[str, Any]]:
        """Fetch user's application history from the server."""
        await self._ensure_session()
        body = {
            "filterFieldParams": [
                {"key": "companyShare.companyIssue.companyISIN.script", "alias": "Scrip"},
                {"key": "companyShare.companyIssue.companyISIN.company.name", "alias": "Company Name"},
            ],
            "searchRoleViewConstants": "VIEW_APPLICANT_FORM_COMPLETE",
            "filterDateParams": [
                {"key": "appliedDate", "condition": "", "alias": "", "value": ""},
                {"key": "appliedDate", "condition": "", "alias": "", "value": ""},
            ],
        }
        if fetch_all:
            return await self._fetch_all_pages("/applicantForm/active/search/", body)
        body["page"] = page
        body["size"] = size
        resp = await self._request(
            self._client, "POST", "/applicantForm/active/search/", json=body,
        )
        return (resp.json() or {}).get("object", [])

    async def get_application_detail(self, applicant_form_id: int) -> dict[str, Any]:
        """Fetch detailed info for a specific application including allotment."""
        await self._ensure_session()
        _pace(0.3, 0.8)
        resp = await self._request(
            self._client, "GET", f"/applicantForm/report/detail/{applicant_form_id}",
        )
        return resp.json()

    # ── Transactions ────────────────────────────────────────────────

    async def get_transactions(
        self, boid: str, from_date: str | None = None, to_date: str | None = None
    ) -> list[dict[str, Any]]:
        await self._ensure_session()
        params: dict[str, str] = {}
        if from_date:
            params["fromDate"] = from_date
        if to_date:
            params["toDate"] = to_date
        resp = await self._request(
            self._view_client, "GET", f"/myTransaction/{boid}", params=params,
        )
        data = resp.json()
        return data if isinstance(data, list) else data.get("object", [])

    async def get_issue_manager_details(self, company_share_id: int) -> dict[str, Any]:
        await self._ensure_session()
        resp = await self._request(
            self._client, "GET", f"/issueManager/detail/{company_share_id}",
        )
        return resp.json()

    async def close(self) -> None:
        await self.logout()
        await asyncio.to_thread(self._client.close)
        await asyncio.to_thread(self._view_client.close)
