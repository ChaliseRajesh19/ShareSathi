import argparse
import asyncio
import getpass
import importlib.metadata
import logging
import signal
import sys

from .client import MeroShareClient
from .server import create_server

_VERSION = importlib.metadata.version("mcp-meroshare")

DESCRIPTION = """
MCP server for MeroShare (CDSC Nepal) — IPO, FPO, and Rights share
applications, portfolio tracking, transaction history, and application
management with allotment results.

Profiles are stored in the OS keychain for secure credential management.
"""

ADD_HELP = """
Create or update a MeroShare profile with your credentials.

You will be prompted for:
  - DP code (from the MeroShare login dropdown)
  - Username (BOID — typically the last 6-7 digits)
  - Password
  - CRN number (from your bank statement)
  - Transaction PIN (4-digit PIN for applying)

If the profile already exists, it will be updated.

If --profile is omitted, the profile is named "default".

Examples:

  $ mcp-meroshare add
  $ mcp-meroshare add myprofile
  $ mcp-meroshare add --profile personal
"""

REMOVE_HELP = """
Remove a stored profile and all its credentials from the keychain.

The --profile option is required.

Examples:

  $ mcp-meroshare remove --profile personal
  $ mcp-meroshare remove --profile work
"""

LIST_HELP = """
List all configured profiles stored in the OS keychain.

Each profile is stored as a separate entry in the OS keychain under
the service name "mcp-meroshare". You can inspect them directly with:

  macOS:   security find-generic-password -s "mcp-meroshare" -a "<profile>"
  Windows: cmdkey /list | findstr mcp-meroshare
  Linux:   secret-tool lookup service mcp-meroshare

Examples:

  $ mcp-meroshare list
"""


class HelpFormatter(argparse.RawDescriptionHelpFormatter):
    def __init__(self, prog):
        super().__init__(prog, max_help_position=32, width=88)


def _make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mcp-meroshare",
        description=DESCRIPTION,
        formatter_class=HelpFormatter,
        add_help=False,
        epilog=(
            "Profiles are stored in the OS keychain (service: mcp-meroshare).\n"
            "Use 'mcp-meroshare <command> --help' for more information "
            "about a specific command."
        ),
    )
    parser.add_argument(
        "-h", "--help",
        action="help",
        default=argparse.SUPPRESS,
        help="Show this help message and exit.",
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"mcp-meroshare v{_VERSION}",
        help="Show the version and exit.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging.",
    )

    sub = parser.add_subparsers(dest="command", metavar="<COMMAND>")

    add_parser = sub.add_parser(
        "add",
        help="Create or update a profile.",
        description=ADD_HELP,
        formatter_class=HelpFormatter,
    )
    add_parser.add_argument(
        "profile_arg", nargs="?", default=None,
        help=argparse.SUPPRESS,
    )
    add_parser.add_argument(
        "--profile", default="default",
        help="Profile name. Defaults to 'default' if omitted.",
    )

    remove_parser = sub.add_parser(
        "remove",
        help="Remove a stored profile.",
        description=REMOVE_HELP,
        formatter_class=HelpFormatter,
    )
    remove_parser.add_argument(
        "--profile",
        required=True,
        help="Profile name to remove (required).",
    )

    list_parser = sub.add_parser(
        "list",
        help="List configured profiles.",
        description=LIST_HELP,
        formatter_class=HelpFormatter,
    )

    return parser


async def _add_profile(profile: str) -> None:
    sys.stderr.write(f"Setting up profile '{profile}'...\n\n")
    dpid = int(input("  DP code (e.g. 10400): "))
    username = input("  Username (BOID): ").strip()
    password = getpass.getpass("  Password: ")
    crn_number = input("  CRN number: ").strip()
    pin_raw = getpass.getpass("  Transaction PIN: ")
    transaction_pin = pin_raw.strip()
    if not transaction_pin:
        print("\nError: Transaction PIN is required for IPO applications.")
        sys.exit(1)

    client = MeroShareClient()
    try:
        dps = await client.get_dp_list()
    except Exception as e:
        print(f"\nFailed to fetch DP list: {e}")
        sys.exit(1)
    finally:
        await client.close()

    client_id = None
    dp_name = str(dpid)
    for dp in dps:
        if int(dp["code"]) == dpid:
            client_id = dp["id"]
            dp_name = f"{dp['name']} ({dp['code']})"
            break

    if client_id is None:
        print(f"\nError: DP code {dpid} not found.")
        matches = [
            dp for dp in dps
            if str(dpid) in str(dp["code"]) or any(w in dp["name"].lower() for w in str(dpid).lower().split())
        ]
        if matches:
            print("Did you mean one of these?")
            for dp in matches[:5]:
                print(f"  {dp['code']}  {dp['name']}")
        print()
        print("Tip: Ask your AI 'what is the DP code for <bank_name>?'")
        print("      (make sure the MCP server status is green)")
        sys.exit(1)

    location = MeroShareClient.save_credentials(
        client_id=client_id,
        username=username,
        password=password,
        crn_number=crn_number,
        profile=profile,
        transaction_pin=transaction_pin,
        dp_name=dp_name,
        dp_code=str(dpid),
    )

    print(f"\n  Profile '{profile}' added.")
    print(f"  DP:    {dp_name}")
    print(f"  PIN:   stored")
    print(f"  Store: {location}")
    print()
    print(f"  You can now apply for IPOs with {profile} in your AI client.")


def cmd_add(profile: str) -> None:
    asyncio.run(_add_profile(profile))


def cmd_remove(profile: str) -> None:
    profiles = MeroShareClient.list_configured_profiles()
    if profile not in profiles:
        print(f"Error: no profile '{profile}' found in keychain.")
        sys.exit(1)

    MeroShareClient.delete_credentials(profile)
    print(f"Profile '{profile}' removed from keychain.")


def cmd_list() -> None:
    profiles = MeroShareClient.list_configured_profiles()
    if not profiles:
        print("No profiles configured.")
        print("Run `mcp-meroshare add` to set one up.")
        return

    name_width = max(len(n) for n in profiles)
    name_width = max(name_width, len("Profile"))

    print(f"Configured profiles ({len(profiles)}):")
    print(f"  {'Profile'.ljust(name_width)}  DP")
    print(f"  {'-' * name_width}  {'-' * 50}")
    for name, info in sorted(profiles.items()):
        dp = info.get("dp_name", "")
        print(f"  {name.ljust(name_width)}  {dp}")


def cmd_server(debug: bool = False) -> None:
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    server, client = create_server()

    async def run() -> None:
        from mcp.server.stdio import stdio_server

        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    task = loop.create_task(run())

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, task.cancel)
        except (NotImplementedError, ValueError):
            pass

    try:
        loop.run_until_complete(task)
    except asyncio.CancelledError:
        pass
    except KeyboardInterrupt:
        task.cancel()
        loop.run_until_complete(asyncio.sleep(0))
    finally:
        if not task.done():
            task.cancel()
            loop.run_until_complete(asyncio.sleep(0))
        loop.run_until_complete(client.close())
        loop.close()


def main() -> None:
    parser = _make_parser()
    args, _ = parser.parse_known_args()

    if args.command == "add":
        profile = args.profile_arg if args.profile_arg else args.profile
        cmd_add(profile)
    elif args.command == "remove":
        cmd_remove(args.profile)
    elif args.command == "list":
        cmd_list()
    else:
        if args.command is not None:
            print(f"Unknown command: {args.command}")
            sys.exit(1)
        if sys.stdin.isatty():
            parser.print_help()
            print(file=sys.stderr)
            print(
                "Note: mcp-meroshare is an MCP server. When run without a subcommand",
                "it starts the MCP server on stdio for AI clients (opencode, Claude).",
                "Use one of the subcommands above for profile management.",
                sep="\n",
                file=sys.stderr,
            )
            sys.exit(0)
        cmd_server(debug=args.debug)


if __name__ == "__main__":
    main()
