import asyncio
from mcp.server import Server
import mcp.types as types

from .client import MeroShareClient
from .tools import auth, issues, application, portfolio


def _send_progress(server: Server, tool_name: str) -> None:
    try:
        ctx = server.request_context
        friendly = tool_name.replace("_", " ").title()
        asyncio.ensure_future(ctx.session.send_log_message(
            level="info",
            data=f"Meroshare {friendly}...",
            logger="mcp-meroshare",
        ))
    except Exception:
        pass


def create_server() -> tuple[Server, MeroShareClient]:
    client = MeroShareClient()
    server = Server("mcp-meroshare")

    @server.list_tools()
    async def handle_list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name="get_dp_list",
                description="Look up Depository Participant (DP) codes. Use the numeric code from the left column as the `dpid` when setting up your account. Does not require login.",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            types.Tool(
                name="login",
                description="Log in to your MeroShare account. Credentials come from the OS keychain (set up via `mcp-meroshare add`) or from environment variables. Switch accounts by providing a different profile name.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "profile": {
                            "type": "string",
                            "description": "Profile name to log in with (default: 'default'). Must match a profile you previously configured.",
                            "default": "default",
                        },
                    },
                },
            ),
            types.Tool(
                name="logout",
                description="Log out of MeroShare and clear your session. Do this when done or before switching accounts.",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            types.Tool(
                name="get_current_issues",
                description="Browse all currently open IPO, FPO, and Rights issues. Uses VIEW_OPEN_SHARE — shows everything open regardless of eligibility.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "fetch_all": {
                            "type": "boolean",
                            "description": "Walk all pages (default: true)",
                            "default": True,
                        },
                        "page": {
                            "type": "integer",
                            "description": "Page number (default 1, used when fetch_all is false)",
                            "default": 1,
                        },
                        "size": {
                            "type": "integer",
                            "description": "Results per page (default 50, max 200)",
                            "default": 50,
                        },
                    },
                },
            ),
            types.Tool(
                name="get_applicable_issues",
                description="Browse issues you are eligible to apply for. Uses VIEW_APPLICABLE_SHARE — narrows to issues your account can participate in.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "fetch_all": {
                            "type": "boolean",
                            "description": "Walk all pages (default: true)",
                            "default": True,
                        },
                        "page": {
                            "type": "integer",
                            "description": "Page number (default 1, used when fetch_all is false)",
                            "default": 1,
                        },
                        "size": {
                            "type": "integer",
                            "description": "Results per page (default 50, max 200)",
                            "default": 50,
                        },
                    },
                },
            ),
            types.Tool(
                name="get_issue_details",
                description="Get detailed info about a specific issue: company name, scrip, min/max kitta, price per unit, and open/close dates.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "company_share_id": {
                            "type": "integer",
                            "description": "The issue ID from the current issues list",
                        },
                    },
                    "required": ["company_share_id"],
                },
            ),
            types.Tool(
                name="get_application_report",
                description="View your application history including allotment status (Allotted / Not Allotted / Pending). Shows what you've applied for and the result.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "fetch_all": {
                            "type": "boolean",
                            "description": "Walk all pages (default: true)",
                            "default": True,
                        },
                        "page": {
                            "type": "integer",
                            "description": "Page number (default 1, used when fetch_all is false)",
                            "default": 1,
                        },
                        "size": {
                            "type": "integer",
                            "description": "Results per page (default 50, max 200)",
                            "default": 50,
                        },
                        "show_detail": {
                            "type": "boolean",
                            "description": "Fetch per-application detail (allotted kitta) — adds N+1 API calls",
                            "default": False,
                        },
                    },
                },
            ),
            types.Tool(
                name="apply_ipo",
                description="Apply for an IPO, FPO, or Rights issue. Use dry_run=true first to preview without submitting. Most parameters come from your account details and linked bank account. customer_id and transaction_pin are auto-resolved from keychain if omitted.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "company_share_id": {
                            "type": "integer",
                            "description": "The issue ID of the IPO/FPO/Rights you want to apply for (from the current issues list)",
                        },
                        "applied_kitta": {
                            "type": "integer",
                            "description": "Number of shares (kitta) to apply for. Must be within the issue's minimum and maximum limits.",
                        },
                        "demat": {
                            "type": "string",
                            "description": "Your 16-digit demat account number (found in your account details)",
                        },
                        "boid": {
                            "type": "string",
                            "description": "Your 16-digit BOID (same as demat number in most cases), found in your account details",
                        },
                        "bank_id": {
                            "type": "integer",
                            "description": "Bank ID from your linked bank account details",
                        },
                        "account_branch_id": {
                            "type": "integer",
                            "description": "Bank branch ID from your linked bank account details",
                        },
                        "account_number": {
                            "type": "string",
                            "description": "Your bank account number linked to MeroShare",
                        },
                        "account_type_id": {
                            "type": "integer",
                            "description": "Account type: 1=SAVING, 2=CURRENT, 3=CALL, 4=LOAN, 5=OTHER (from your bank details)",
                        },
                        "customer_id": {
                            "type": "integer",
                            "description": "Your profile ID from MeroShare. Auto-resolved from profile if omitted.",
                        },
                        "dry_run": {
                            "type": "boolean",
                            "description": "If true, preview what would be submitted without actually applying",
                            "default": False,
                        },
                    },
                    "required": [
                        "company_share_id", "applied_kitta",
                        "demat", "boid", "bank_id", "account_branch_id",
                        "account_number", "account_type_id",
                    ],
                },
            ),
            types.Tool(
                name="get_bank_details",
                description="Retrieve your linked bank account details needed for IPO applications. Returns bank ID, branch, account number, account type, and customer ID.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "demat": {
                            "type": "string",
                            "description": "Your 16-digit demat account number (found in your account details)",
                        },
                    },
                    "required": ["demat"],
                },
            ),
            types.Tool(
                name="get_own_detail",
                description="View your account profile: full name, BOID, demat number, email, and contact info.",
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
            types.Tool(
                name="get_transactions",
                description="View your share transaction history (buy/sell records). Optionally filter by date range. Your BOID is required.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "boid": {
                            "type": "string",
                            "description": "Your BOID number (Beneficial Owner ID), found in your account details",
                        },
                        "from_date": {
                            "type": "string",
                            "description": "Start date for filtering (YYYY-MM-DD format, e.g. '2026-01-01'). Optional.",
                        },
                        "to_date": {
                            "type": "string",
                            "description": "End date for filtering (YYYY-MM-DD format, e.g. '2026-06-20'). Optional.",
                        },
                    },
                    "required": ["boid"],
                },
            ),
        ]

    @server.call_tool()
    async def handle_call_tool(
        name: str, arguments: dict
    ) -> list[types.TextContent]:
        _send_progress(server, name)

        tool_map = {
            "login": auth.handle_meroshare_login,
            "logout": auth.handle_meroshare_logout,
            "get_dp_list": auth.handle_meroshare_get_dp_list,
            "get_current_issues": issues.handle_meroshare_get_current_issues,
            "get_applicable_issues": issues.handle_meroshare_get_applicable_issues,
            "get_issue_details": issues.handle_meroshare_get_issue_details,
            "get_application_report": application.handle_meroshare_get_application_report,
            "apply_ipo": application.handle_meroshare_apply_ipo,
            "get_bank_details": application.handle_meroshare_get_bank_details,
            "get_own_detail": portfolio.handle_meroshare_get_own_detail,
            "get_transactions": portfolio.handle_meroshare_get_transactions,
        }

        handler = tool_map.get(name)
        if handler is None:
            return [types.TextContent(
                type="text",
                text=f"Unknown tool: {name}",
                isError=True,
            )]

        if not client.logged_in and name not in ("login", "get_dp_list"):
            return [types.TextContent(
                type="text",
                text="Not logged in. Call login first.",
            )]

        return await handler(client, arguments)

    return server, client
