import mcp.types as types
from ..client import MeroShareClient, format_error
from .format import md_section, md_table, dt


async def handle_meroshare_get_own_detail(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        d = await client.get_own_detail()

        info = [
            ("Name", dt(d.get("name", ""))),
            ("BOID", f"`{d.get('boid', '')}`"),
            ("Demat", f"`{d.get('demat', '')}`"),
            ("Email", dt(d.get("email", ""))),
            ("Contact", dt(d.get("contact", ""))),
            ("Address", dt(d.get("address", ""))),
            ("Gender", dt(d.get("gender", ""))),
        ]

        text = "**Your Profile**\n\n"
        for label, value in info:
            text += f"  **{label}:** {value}\n"

        text += (
            "\nUse this info with other tools:\n"
            "  • `boid` → `meroshare_get_transactions`\n"
            "  • `demat` → `meroshare_get_bank_details`"
        )
        return [types.TextContent(type="text", text=text)]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch own details: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_get_transactions(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        transactions = await client.get_transactions(
            boid=arguments["boid"],
            from_date=arguments.get("from_date"),
            to_date=arguments.get("to_date"),
        )
        if not transactions:
            return [types.TextContent(type="text", text="No transactions found.")]

        rows = []
        for tx in transactions:
            rows.append([
                dt(tx.get("transactionNo", "")),
                dt(tx.get("scrip", "")),
                dt(tx.get("companyName", "")),
                dt(tx.get("buySell", "")),
                dt(tx.get("quantity", "")),
                dt(tx.get("rate", "")),
                dt(tx.get("amount", "")),
                dt(tx.get("transactionDate", "")),
            ])

        table = md_table(
            ["No", "Scrip", "Company", "Type", "Qty", "Rate", "Amount", "Date"],
            rows,
        )
        return [types.TextContent(
            type="text",
            text=f"**Transaction History** ({len(transactions)} records)\n\n{table}"
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch transactions: {format_error(e)}",
            isError=True,
        )]
