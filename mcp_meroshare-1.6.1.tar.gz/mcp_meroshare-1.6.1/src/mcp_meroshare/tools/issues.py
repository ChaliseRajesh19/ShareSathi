import mcp.types as types
from ..client import MeroShareClient, format_error
from .format import md_table, md_section, dt


def _format_date(raw: str) -> str:
    return raw.replace(" 12:00:00 AM", "").strip()


def _format_issue_row(issue: dict) -> list[str]:
    return [
        f"`{issue.get('companyShareId', '?')}`",
        dt(issue.get("scrip", "")),
        dt(issue.get("companyName", "")),
        dt(issue.get("shareTypeName", "")),
        _format_date(dt(issue.get("issueOpenDate", ""))),
        _format_date(dt(issue.get("issueCloseDate", ""))),
    ]


async def handle_meroshare_get_current_issues(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        fetch_all = arguments.get("fetch_all", True)
        page = arguments.get("page", 1)
        size = arguments.get("size", 50)
        issues = await client.get_current_open_issues(fetch_all=fetch_all, page=page, size=size)
        if not issues:
            return [types.TextContent(type="text", text="No open issues found at this time.")]

        rows = [_format_issue_row(i) for i in issues]
        table = md_table(["ID", "Scrip", "Company", "Type", "Opens", "Closes"], rows)
        return [types.TextContent(type="text", text=f"**Current Open Issues** ({len(issues)} found)\n\n{table}")]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch current issues: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_get_applicable_issues(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        fetch_all = arguments.get("fetch_all", True)
        page = arguments.get("page", 1)
        size = arguments.get("size", 50)
        issues = await client.get_applicable_issues(fetch_all=fetch_all, page=page, size=size)
        if not issues:
            return [types.TextContent(type="text", text="No applicable issues found.")]

        rows = [_format_issue_row(i) for i in issues]
        table = md_table(["ID", "Scrip", "Company", "Type", "Opens", "Closes"], rows)
        return [types.TextContent(type="text", text=f"**Applicable Issues** ({len(issues)} found)\n\n{table}")]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch applicable issues: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_get_issue_details(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        company_share_id = arguments["company_share_id"]
        detail = await client.get_issue_details(company_share_id)
        if not detail:
            return [types.TextContent(type="text", text="Issue not found.")]

        items = [
            ("Company", dt(detail.get("companyName", ""))),
            ("Scrip", dt(detail.get("scrip", ""))),
            ("Share Type", dt(detail.get("shareTypeName", ""))),
            ("Min Kitta", str(detail.get("minUnit", "?"))),
            ("Max Kitta", str(detail.get("maxUnit", "?"))),
            ("Price per Unit", f"Rs. {detail.get('sharePerUnit', '?')}"),
            ("Opens", dt(detail.get("issueOpenDate", ""))),
            ("Closes", dt(detail.get("issueCloseDate", ""))),
        ]

        return [types.TextContent(
            type="text",
            text=f"**Issue Details** — `{company_share_id}`\n\n" +
                 "\n".join(f"  **{k}:** {v}" for k, v in items),
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch issue details: {format_error(e)}",
            isError=True,
        )]
