import mcp.types as types
from ..client import MeroShareClient, format_error
from .format import md_table, dt


async def handle_meroshare_login(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        profile = arguments.get("profile", "default")
        await client.login(profile=profile)
        own = await client.get_own_detail()
        name = own.get("name") or own.get("fullName", "User")
        return [types.TextContent(
            type="text",
            text=f"**Logged in** — **{name}** (profile: `{profile}`)\n\n"
                 f"Ready to use `meroshare_get_own_detail`, `meroshare_get_current_issues`, etc."
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Login failed: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_logout(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        await client.logout()
        return [types.TextContent(type="text", text="**Logged out** — session cleared.")]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Logout failed: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_get_dp_list(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        dps = await client.get_dp_list()
        rows = []
        for dp in dps:
            rows.append([f"`{dp['code']}`", dt(dp['name'])])
        table = md_table(["Code", "Depository Participant Name"], rows)
        return [types.TextContent(
            type="text",
            text=f"**Available Depository Participants**\n\n"
                 f"Use the **code** number (left column) with `mcp-meroshare add`.\n\n"
                 f"{table}"
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch DP list: {format_error(e)}",
            isError=True,
        )]
