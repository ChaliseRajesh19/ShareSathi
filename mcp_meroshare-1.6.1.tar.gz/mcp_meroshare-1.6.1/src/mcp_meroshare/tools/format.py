"""Shared output formatting for readable opencode terminal output."""

from typing import Any


def md_table(headers: list[str], rows: list[list[str]]) -> str:
    """Build a markdown table from headers and rows."""
    lines = ["| " + " | ".join(headers) + " |"]
    lines.append("| " + " | ".join("---" for _ in headers) + " |")
    for row in rows:
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def md_section(title: str, items: list[tuple[str, str]]) -> str:
    """Build a markdown section with bold labels."""
    parts = [f"**{title}**", ""]
    for label, value in items:
        parts.append(f"  **{label}:** {value}")
    return "\n".join(parts)


def md_code(text: str, lang: str = "json") -> str:
    return f"```{lang}\n{text}\n```"


def dt(value: Any) -> str:
    """Convert a value to display string."""
    if value is None:
        return "-"
    s = str(value)
    if len(s) > 120:
        return s[:117] + "..."
    return s
