import json
import mcp.types as types
from ..client import MeroShareClient, format_error
from .format import md_section, md_table, dt


_REQUIRED_APPLY_FIELDS = [
    "company_share_id", "applied_kitta", "demat", "boid",
    "bank_id", "account_branch_id", "account_number",
    "account_type_id",
]

async def handle_meroshare_apply_ipo(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        missing = [k for k in _REQUIRED_APPLY_FIELDS if k not in arguments]
        if missing:
            return [types.TextContent(
                type="text",
                text=f"Missing required fields: {', '.join(missing)}.",
                isError=True,
            )]

        transaction_pin = client.transaction_pin
        if not transaction_pin:
            return [types.TextContent(
                type="text",
                text="transaction_pin is not configured. Run `mcp-meroshare add` to store it in the keychain.",
                isError=True,
            )]
        company_share_id = arguments["company_share_id"]
        demat = arguments["demat"]

        if len(demat) == 0:
            return [types.TextContent(
                type="text", text="demat must not be empty.", isError=True,
            )]
        if len(arguments.get("boid", "")) < 8:
            return [types.TextContent(
                type="text", text="boid seems too short (expected 8+ digits).", isError=True,
            )]

        if "customer_id" not in arguments:
            own_detail = await client.get_own_detail()
            customer_id = own_detail.get("id")
            if not customer_id:
                return [types.TextContent(
                    type="text",
                    text="Could not auto-resolve customer_id from profile. "
                         "Run meroshare_get_own_detail first and pass customer_id explicitly.",
                    isError=True,
                )]
            arguments["customer_id"] = int(customer_id)

        can_apply = await client.can_apply_to_ipo(company_share_id, demat)
        if not can_apply:
            return [types.TextContent(
                type="text",
                text="Cannot apply to this IPO. You may have already applied or it may not be open for your account.",
                isError=True,
            )]

        payload = {
            "accountBranchId": arguments["account_branch_id"],
            "accountNumber": arguments["account_number"],
            "accountTypeId": arguments["account_type_id"],
            "appliedKitta": str(arguments["applied_kitta"]),
            "bankId": arguments["bank_id"],
            "boid": arguments["boid"],
            "companyShareId": str(company_share_id),
            "crnNumber": client.crn_number,
            "customerId": arguments["customer_id"],
            "demat": demat,
            "transactionPIN": transaction_pin,
        }

        if arguments.get("dry_run", False):
            display = {**payload, "crnNumber": "****", "transactionPIN": "****"}
            return [types.TextContent(
                type="text",
                text=f"**DRY RUN** — This is what would be submitted:\n\n"
                     f"```json\n{json.dumps(display, indent=2)}\n```\n\n"
                     f"To apply for real, call again with `dry_run: false`.",
            )]

        result = await client.apply_for_ipo(payload)
        msg = result.get("message", "Application submitted.")
        return [types.TextContent(
            type="text",
            text=f"**IPO Application Submitted**\n\n"
                 f"  **Response:** {dt(msg)}\n"
                 f"  **Company Share ID:** `{company_share_id}`\n"
                 f"  **Applied Kitta:** `{arguments['applied_kitta']}`\n"
                 f"  **Demat:** `{demat}`\n\n"
                 f"```json\n{json.dumps(result, indent=2, default=str)}\n```",
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"IPO application failed: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_get_application_report(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        fetch_all = arguments.get("fetch_all", True)
        page = arguments.get("page", 1)
        size = arguments.get("size", 50)
        show_detail = arguments.get("show_detail", False)
        reports = await client.get_application_report(fetch_all=fetch_all, page=page, size=size)
        if not reports:
            return [types.TextContent(type="text", text="No applications found.")]

        rows = []
        for r in reports:
            allotted_kitta = r.get("allottedKitta")
            if allotted_kitta is None and show_detail:
                applicant_id = r.get("id")
                if applicant_id is not None:
                    try:
                        detail = await client.get_application_detail(int(applicant_id))
                        allotted_kitta = detail.get("allottedKitta")
                    except Exception:
                        pass

            if allotted_kitta is not None:
                try:
                    k = int(allotted_kitta)
                    alloted_str = f"Yes ({k})" if k > 0 else "-"
                except (ValueError, TypeError):
                    alloted_str = "-"
            else:
                alloted_str = "-"

            rows.append([
                f"`{r.get('companyShareId', '?')}`",
                dt(r.get("companyName", "")),
                dt(r.get("shareTypeName", "")),
                str(r.get("appliedKitta", "?")),
                f"Rs. {r.get('amount', '?')}",
                dt(r.get("statusName", r.get("status", "?")).replace("alloted", "allotted").replace("Alloted", "Allotted")),
                alloted_str,
                dt(r.get("appliedDate", "")),
            ])

        table = md_table(
            ["ID", "Company", "Type", "Kitta", "Amount", "Status", "Allotted", "Date"],
            rows,
        )
        return [types.TextContent(
            type="text",
            text=f"**Application Report** ({len(reports)} records)\n\n{table}"
        )]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch application report: {format_error(e)}",
            isError=True,
        )]


async def handle_meroshare_get_bank_details(client: MeroShareClient, arguments: dict) -> list[types.TextContent]:
    try:
        details = await client.get_bank_details(arguments["demat"])
        if not details:
            return [types.TextContent(type="text", text="No bank details found for this demat.")]

        parts = [f"**Linked Bank Details** (demat: `{arguments['demat']}`)\n"]
        for bank in details:
            parts.append(f"\n  **Bank:** {dt(bank.get('bankName', '?'))}  (ID: `{bank.get('bankId', '?')}`)")
            parts.append(f"  **Account:** `{bank.get('accountNumber', '?')}`")
            parts.append(f"  **Account Branch ID:** `{bank.get('accountBranchId', '?')}`")
            parts.append(f"  **Account Type:** {bank.get('accountTypeName', '?')} (ID: `{bank.get('accountTypeId', '?')}`)")
            parts.append(f"  **Branch Name:** {dt(bank.get('branchName', '?'))}")

        own_detail = await client.get_own_detail()
        parts.append(f"\n  **Customer ID:** `{own_detail.get('id', '?')}` (from profile)")

        parts.append(
            "\n\nUse these IDs with `meroshare_apply_ipo`:\n"
            "  `bank_id`, `account_branch_id`, `account_number`, "
            "`account_type_id`, `customer_id`"
        )
        return [types.TextContent(type="text", text="\n".join(parts))]
    except Exception as e:
        return [types.TextContent(
            type="text",
            text=f"Failed to fetch bank details: {format_error(e)}",
            isError=True,
        )]
