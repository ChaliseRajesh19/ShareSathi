# mcp-meroshare

[![PyPI version](https://img.shields.io/pypi/v/mcp-meroshare.svg)](https://pypi.org/project/mcp-meroshare/)
[![Python Versions](https://img.shields.io/pypi/pyversions/mcp-meroshare.svg)](https://pypi.org/project/mcp-meroshare/)
[![License](https://img.shields.io/pypi/l/mcp-meroshare.svg)](https://github.com/anomalyco/mcp-meroshare/blob/main/LICENSE)

MCP (Model Context Protocol) server for [MeroShare](https://meroshare.cdsc.com.np) — Nepal's online share application system by CDSC Nepal. Lets AI assistants manage IPO/FPO applications, portfolio, and share transactions through any MCP-compatible client (opencode, Claude, VS Code, etc.).

Credentials are stored in your **OS keychain** — the AI model never reads them.

## Features

- **IPO/FPO/Rights Application** — view open issues, apply with dry-run preview
- **Portfolio** — check holdings and transaction history
- **Account** — view DP list, own details, linked bank accounts
- **Allotment Tracking** — application status with allotted kitta
- **Multiple Accounts** — switch between profiles (personal, family, office)
- **Security** — credentials in OS keychain, never exposed to the AI model

## Installation

```bash
pip install mcp-meroshare
```

Python 3.10+ required.

## Quick Start

### 1. Find your DP code

Ask the AI for the DP code (e.g. "what's the DP code for Nabil Bank?").

### 2. Add credentials

```bash
mcp-meroshare add
```

You'll be prompted for: DP code, username (BOID), password, CRN number, and transaction PIN (optional). Saved to your OS keychain.

### 3. Log in and apply

Ask the AI to log in, check open issues, and apply for an IPO. You can also ask for a dry-run preview first to see what would be submitted.

## Multiple Accounts

```bash
mcp-meroshare add --profile user_name
```

Then ask the AI to log in using that profile.

## CLI

```
mcp-meroshare -h                       Show help
mcp-meroshare add                      Interactive credential setup
mcp-meroshare add --profile user_name  Set up a specific profile
mcp-meroshare remove --profile default Remove a profile from keychain
mcp-meroshare list                     Show all configured profiles
mcp-meroshare --version                Show version
```

## Package

This is an MCP server package. It provides:

- **MCP stdio server** — exposes MeroShare operations as MCP tools for any MCP client to consume
- **CLI** — `mcp-meroshare` command for credential management (add/remove/list profiles via OS keychain)
- **Python client** — reusable `MeroShareClient` for the MeroShare API (can be used standalone)

See `pyproject.toml` for entry points and dependencies.

## License

MIT
